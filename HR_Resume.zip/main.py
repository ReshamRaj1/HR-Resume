import streamlit as st
import torch
from transformers import AutoTokenizer, AutoModel
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import io
from PyPDF2 import PdfReader
from docx import Document

# Load BERT model and tokenizer
@st.cache_resource
def load_model():
    """
    Loads the pre-trained BERT model and tokenizer for text embeddings.
    
    Returns:
        tokenizer: The pre-trained tokenizer for BERT model.
        model: The pre-trained BERT model.
    """
    model_name = "bert-large-uncased"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    return tokenizer, model

tokenizer, model = load_model()

# Function to compute embeddings
def get_embedding(text, tokenizer, model):
    """
    Computes the embedding for a given text using the BERT model.

    Args:
        text (str): The input text to be embedded.
        tokenizer: The pre-trained tokenizer.
        model: The pre-trained BERT model.

    Returns:
        torch.Tensor: The computed embedding as a tensor.
    """
    tokens = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
    with torch.no_grad():
        outputs = model(**tokens)
    return outputs.last_hidden_state.mean(dim=1).squeeze()

# Function to evaluate resumes
def evaluate_resumes(job_description, resumes, filenames):
    """
    Evaluates the similarity between the job description and each resume.

    Args:
        job_description (str): The job description text.
        resumes (list): A list of resume text to be compared.

    Returns:
        list: A list of dictionaries containing resume names and their similarity scores.
    """
    job_embedding = get_embedding(job_description, tokenizer, model)
    results = []

    for idx, resume in enumerate(resumes):
        resume_embedding = get_embedding(resume, tokenizer, model)
        similarity = cosine_similarity(
            job_embedding.reshape(1, -1), resume_embedding.reshape(1, -1)
        )[0][0]
        results.append({"Resume": filenames[idx], "Similarity Score": similarity})

    return results

# Function to extract text from uploaded file
def extract_text_from_file(file):
    """
    Extracts text content from the given file based on its type.

    Args:
        file (UploadedFile): The uploaded file object from Streamlit's file uploader.

    Returns:
        str: The extracted text content from the file if the file type is supported (PDF, DOCX, or TXT).
        None: If the file type is unsupported.

    Supported file types:
        - PDF: Text is extracted from all pages using PyPDF2.
        - DOCX: Text is extracted from all paragraphs using python-docx.
        - TXT: Text is read directly from the file content.

    If an unsupported file type is provided (other than PDF, DOCX, or TXT), the function will return None.
    """
    # Check file type and extract text accordingly
    file_type = file.type.lower()

    if file_type == "application/pdf":
        # Extract text from PDF
        pdf_reader = PdfReader(io.BytesIO(file.read()))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text()
        return text

    elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        # Extract text from DOCX
        doc = Document(io.BytesIO(file.read()))
        text = ""
        for para in doc.paragraphs:
            text += para.text
        return text

    elif file_type == "text/plain":
        # Extract text from TXT
        return file.read().decode("utf-8")

    else:
        # Handle unsupported file types
        return None

# Streamlit UI
def main():
    """
    The main function that runs the Streamlit UI, allowing the user to upload resumes,
    input job description, and evaluate the similarity of resumes.
    """
    st.title("AI-Powered Resume Screening with BERT")
    st.write("Upload resumes and compare them against a job description to find the best candidates.")
    
    # Input for job description
    job_description = st.text_area(
        "Job Description", 
        placeholder="Enter the job description here...", 
        height=200
    )
    
    # Upload resumes
    uploaded_files = st.file_uploader("Upload Resumes (PDF, DOCX, TXT, etc.)", accept_multiple_files=True)
    
    if st.button("Screen Resumes"):
        if not job_description.strip():
            st.error("Please enter a job description.")
        elif not uploaded_files:
            st.error("Please upload at least one resume.")
        else:
            # Read resumes from uploaded files
            resumes = []
            filenames = []  # List to store filenames
            for file in uploaded_files:
                text = extract_text_from_file(file)
                if text:
                    resumes.append(text)
                    filenames.append(file.name)  # Save the file name
                else:
                    st.warning(f"Unsupported file type for {file.name}. Please upload a PDF, DOCX, or TXT file.")
                    return
    
            # Evaluate resumes using BERT
            with st.spinner("Screening resumes..."):
                results = evaluate_resumes(job_description, resumes, filenames)
    
            # Display results
            st.subheader("Screening Results")
            results_df = pd.DataFrame(results).sort_values(by="Similarity Score", ascending=False)
            st.dataframe(results_df)
    
            # Highlight the best candidate(s)
            top_candidate = results_df.iloc[0]
            st.success(
                f"Top Candidate: {top_candidate['Resume']} with a similarity score of {top_candidate['Similarity Score']:.2f}"
            )

# Run the application
if __name__ == "__main__":
    main()